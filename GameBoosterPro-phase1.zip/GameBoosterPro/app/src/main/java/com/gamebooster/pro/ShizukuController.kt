package com.gamebooster.pro

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_INSTALLED, NOT_RUNNING, PERMISSION_NEEDED, DENIED, CONNECTING, READY }

class ShizukuController(private val context: Context) {

    var state by mutableStateOf(ShizukuState.NOT_RUNNING)
        private set

    /** Every command and its result (shown in the Log card). */
    val log = mutableStateListOf<String>()

    @Volatile private var service: IUserService? = null
    private var binding = false
    private var denied = false

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(context.packageName, UserService::class.java.name)
    ).daemon(false).processNameSuffix("shell").debuggable(false).version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            if (binder.pingBinder()) {
                service = IUserService.Stub.asInterface(binder)
                update()
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            binding = false
            update()
        }
    }

    private val onBinderReceived = Shizuku.OnBinderReceivedListener { update() }
    private val onBinderDead = Shizuku.OnBinderDeadListener {
        service = null
        binding = false
        update()
    }
    private val onPermissionResult =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            denied = grantResult != PackageManager.PERMISSION_GRANTED
            update()
        }

    init {
        Shizuku.addBinderReceivedListenerSticky(onBinderReceived)
        Shizuku.addBinderDeadListener(onBinderDead)
        Shizuku.addRequestPermissionResultListener(onPermissionResult)
    }

    fun close() {
        Shizuku.removeBinderReceivedListener(onBinderReceived)
        Shizuku.removeBinderDeadListener(onBinderDead)
        Shizuku.removeRequestPermissionResultListener(onPermissionResult)
    }

    private fun isInstalled(): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    fun update() {
        state = try {
            when {
                !Shizuku.pingBinder() ->
                    if (isInstalled()) ShizukuState.NOT_RUNNING else ShizukuState.NOT_INSTALLED
                Shizuku.isPreV11() -> ShizukuState.NOT_RUNNING
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                    if (denied) ShizukuState.DENIED else ShizukuState.PERMISSION_NEEDED
                service != null -> ShizukuState.READY
                else -> {
                    bind()
                    ShizukuState.CONNECTING
                }
            }
        } catch (e: Throwable) {
            ShizukuState.NOT_RUNNING
        }
    }

    private fun bind() {
        if (binding) return
        binding = true
        try {
            Shizuku.bindUserService(userServiceArgs, connection)
        } catch (e: Throwable) {
            binding = false
            addLog("bind failed: ${e.message}")
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) {
                denied = false
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (e: Throwable) {
            addLog("permission request failed: ${e.message}")
        }
    }

    /** Runs a whitelisted command off the main thread. Never throws. */
    suspend fun run(command: String): ShellResult {
        val result = withContext(Dispatchers.IO) {
            val svc = service
            when {
                !Commands.isAllowed(command) -> ShellResult(-1, "Blocked: command is not whitelisted")
                svc == null -> ShellResult(-1, "Shizuku service is not connected")
                else -> try {
                    Commands.parse(svc.exec(command))
                } catch (e: Throwable) {
                    ShellResult(-1, e.message ?: "unknown error")
                }
            }
        }
        addLog("$ $command\n  -> exit ${result.code}${if (result.output.isNotEmpty()) ": " + result.output else ""}")
        return result
    }

    private fun addLog(line: String) {
        log.add(line)
        while (log.size > 100) log.removeAt(0)
    }

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        private const val REQUEST_CODE = 1001
    }
}
