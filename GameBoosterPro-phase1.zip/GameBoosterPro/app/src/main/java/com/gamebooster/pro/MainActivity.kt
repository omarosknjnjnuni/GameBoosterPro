package com.gamebooster.pro

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val SHIZUKU_URL = "https://github.com/RikkaApps/Shizuku/releases"

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00E676),
                    onPrimary = Color(0xFF00210E),
                    background = Color(0xFF0B0F14),
                    surface = Color(0xFF141A22),
                    onSurface = Color(0xFFE6EDF3),
                    onBackground = Color(0xFFE6EDF3)
                )
            ) {
                Screen(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.onResume()
    }
}

@Composable
private fun Screen(vm: MainViewModel) {
    val ctx = LocalContext.current
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium)
            }
            item { ShizukuCard(vm, ctx) }
            item { DisplayCard(vm) }
            item { ActionsCard(vm) }
            item { LogCard(vm) }
        }
    }
}

@Composable
private fun ShizukuCard(vm: MainViewModel, ctx: Context) {
    val state = vm.shizuku.state
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.card_shizuku), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(
                    when (state) {
                        ShizukuState.NOT_INSTALLED -> R.string.st_not_installed
                        ShizukuState.NOT_RUNNING -> R.string.st_not_running
                        ShizukuState.PERMISSION_NEEDED -> R.string.st_perm_needed
                        ShizukuState.DENIED -> R.string.st_denied
                        ShizukuState.CONNECTING -> R.string.st_connecting
                        ShizukuState.READY -> R.string.st_ready
                    }
                ),
                color = if (state == ShizukuState.READY) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface
            )
            when (state) {
                ShizukuState.NOT_INSTALLED -> {
                    Text(stringResource(R.string.guide_start), fontSize = 13.sp)
                    OutlinedButton(
                        onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SHIZUKU_URL))) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.btn_get_shizuku)) }
                }
                ShizukuState.NOT_RUNNING -> {
                    Text(stringResource(R.string.guide_start), fontSize = 13.sp)
                    OutlinedButton(
                        onClick = {
                            ctx.packageManager.getLaunchIntentForPackage(ShizukuController.SHIZUKU_PACKAGE)
                                ?.let { ctx.startActivity(it) }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.btn_open_shizuku)) }
                }
                ShizukuState.PERMISSION_NEEDED, ShizukuState.DENIED -> {
                    Button(
                        onClick = { vm.shizuku.requestPermission() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.btn_request_perm)) }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun DisplayCard(vm: MainViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.card_display), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(
                    R.string.supported_rates,
                    vm.rates.joinToString(", ") { Commands.label(it) }
                )
            )
            Text(stringResource(R.string.current_rate, Commands.label(vm.currentRate)))
        }
    }
}

@Composable
private fun ActionsCard(vm: MainViewModel) {
    val enabled = vm.shizuku.state == ShizukuState.READY && !vm.busy
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.applyMaxRefresh() },
                enabled = enabled,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.btn_apply)) }
            OutlinedButton(
                onClick = { vm.restore() },
                enabled = enabled,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.btn_restore)) }
            OutlinedButton(
                onClick = { vm.grantSecure() },
                enabled = enabled,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.btn_grant)) }
            if (vm.message.isNotEmpty()) {
                Text(vm.message, fontSize = 13.sp)
            }
            Text(stringResource(R.string.disclaimer), fontSize = 12.sp, color = Color(0xFF8B98A5))
        }
    }
}

@Composable
private fun LogCard(vm: MainViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.log_title), style = MaterialTheme.typography.titleMedium)
            val entries = vm.shizuku.log.takeLast(15).reversed()
            if (entries.isEmpty()) {
                Text(stringResource(R.string.log_empty), fontSize = 12.sp)
            } else {
                entries.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}
