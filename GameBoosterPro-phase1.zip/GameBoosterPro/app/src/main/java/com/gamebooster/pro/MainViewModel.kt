package com.gamebooster.pro

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.view.Display
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val shizuku = ShizukuController(app)
    private val prefs = app.getSharedPreferences("backup", Context.MODE_PRIVATE)

    var rates by mutableStateOf<List<Float>>(emptyList())
        private set
    var currentRate by mutableStateOf(0f)
        private set
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf("")
        private set

    init {
        refreshDisplay()
        shizuku.update()
    }

    private fun s(id: Int, vararg args: Any): String =
        getApplication<Application>().getString(id, *args)

    fun onResume() {
        refreshDisplay()
        shizuku.update()
    }

    fun refreshDisplay() {
        val dm = getApplication<Application>().getSystemService(DisplayManager::class.java)
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY) ?: return
        rates = display.supportedModes
            .map { (it.refreshRate * 10).roundToInt() / 10f }
            .distinct()
            .sorted()
        currentRate = display.refreshRate
    }

    private fun launchBusy(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        viewModelScope.launch {
            try {
                block()
            } finally {
                busy = false
            }
        }
    }

    /** Saves the original values once, before the first change. */
    private suspend fun backupOriginals(): Boolean {
        if (prefs.getBoolean(KEY_DONE, false)) return true
        val values = mutableMapOf<String, String>()
        for (k in Commands.Key.entries) {
            val r = shizuku.run(Commands.get(k))
            if (!r.ok) return false
            values[k.name] = r.output.trim()
        }
        val e = prefs.edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.putBoolean(KEY_DONE, true)
        return e.commit()
    }

    fun applyMaxRefresh() {
        val max = rates.maxOrNull()
        if (max == null) {
            message = s(R.string.msg_no_rates)
            return
        }
        launchBusy {
            if (!backupOriginals()) {
                message = s(R.string.msg_failed, "backup")
                return@launchBusy
            }
            val v = Commands.formatRate(max)
            val r1 = shizuku.run(Commands.put(Commands.Key.PEAK, v))
            val r2 = shizuku.run(Commands.put(Commands.Key.MIN, v))
            if (!r1.ok || !r2.ok) {
                message = s(R.string.msg_failed, (r1.output + " " + r2.output).trim())
                return@launchBusy
            }
            val peak = shizuku.run(Commands.get(Commands.Key.PEAK)).output
            val min = shizuku.run(Commands.get(Commands.Key.MIN)).output
            delay(1500)
            refreshDisplay()
            message = s(R.string.msg_applied, peak, min)
        }
    }

    fun restore() {
        launchBusy {
            if (!prefs.getBoolean(KEY_DONE, false)) {
                message = s(R.string.msg_no_backup)
                return@launchBusy
            }
            var allOk = true
            var err = ""
            for (k in Commands.Key.entries) {
                val saved = prefs.getString(k.name, "null") ?: "null"
                // "null" means the key was unset originally -> delete it again.
                val cmd = if (Commands.isValidValue(saved)) Commands.put(k, saved) else Commands.delete(k)
                val r = shizuku.run(cmd)
                if (!r.ok) {
                    allOk = false
                    err = r.output
                }
            }
            if (allOk) {
                prefs.edit().putBoolean(KEY_DONE, false).apply()
                message = s(R.string.msg_restored)
            } else {
                message = s(R.string.msg_failed, err)
            }
            delay(1500)
            refreshDisplay()
        }
    }

    fun grantSecure() {
        launchBusy {
            val app = getApplication<Application>()
            val r = shizuku.run(Commands.grantWriteSecure(app.packageName))
            val has = app.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
                PackageManager.PERMISSION_GRANTED
            message = when {
                r.ok && has -> s(R.string.msg_granted)
                r.ok -> s(R.string.msg_not_granted)
                else -> s(R.string.msg_failed, r.output)
            }
        }
    }

    override fun onCleared() {
        shizuku.close()
        super.onCleared()
    }

    private companion object {
        const val KEY_DONE = "done"
    }
}
