package com.gamebooster.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandsTest {

    @Test fun putBuildsExpectedCommand() {
        assertEquals(
            "settings put system peak_refresh_rate 120.0",
            Commands.put(Commands.Key.PEAK, "120.0")
        )
    }

    @Test fun putRejectsInjection() {
        assertThrows(IllegalArgumentException::class.java) {
            Commands.put(Commands.Key.MIN, "1; rm -rf /")
        }
    }

    @Test fun whitelistAcceptsKnownCommands() {
        assertTrue(Commands.isAllowed(Commands.get(Commands.Key.PEAK)))
        assertTrue(Commands.isAllowed(Commands.delete(Commands.Key.MIN)))
        assertTrue(Commands.isAllowed(Commands.put(Commands.Key.MIN, "90.0")))
        assertTrue(Commands.isAllowed(Commands.grantWriteSecure("com.gamebooster.pro")))
    }

    @Test fun whitelistRejectsOthers() {
        assertFalse(Commands.isAllowed("rm -rf /"))
        assertFalse(Commands.isAllowed("settings put system peak_refresh_rate 120; reboot"))
        assertFalse(Commands.isAllowed("pm grant com.x android.permission.CAMERA"))
    }

    @Test fun grantRejectsBadPackage() {
        assertThrows(IllegalArgumentException::class.java) {
            Commands.grantWriteSecure("a b;c")
        }
    }

    @Test fun formatsRates() {
        assertEquals("120.0", Commands.formatRate(120f))
        assertEquals("120", Commands.label(120f))
        assertEquals("59.9", Commands.label(59.9f))
    }

    @Test fun parsesShellOutput() {
        assertEquals(ShellResult(0, "null"), Commands.parse("0\nnull\n"))
        assertEquals(ShellResult(1, "err"), Commands.parse("1\nerr"))
        assertFalse(Commands.parse("garbage").ok)
    }
}
