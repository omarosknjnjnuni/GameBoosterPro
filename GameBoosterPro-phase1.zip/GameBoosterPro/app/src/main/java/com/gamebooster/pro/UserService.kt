package com.gamebooster.pro

import android.content.Context
import androidx.annotation.Keep
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/** Runs inside the Shizuku-started process (shell privileges). */
class UserService : IUserService.Stub {

    constructor() : super()

    @Keep
    constructor(context: Context) : super()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val sb = StringBuilder()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { sb.appendLine(it) }
                } catch (e: Exception) {
                    // stream closed
                }
            }
            reader.start()
            val finished = p.waitFor(10, TimeUnit.SECONDS)
            if (!finished) p.destroyForcibly()
            reader.join(1000)
            val code = if (finished) p.exitValue() else -2
            "$code\n$sb"
        } catch (e: Exception) {
            "-1\n${e.message}"
        }
    }
}
