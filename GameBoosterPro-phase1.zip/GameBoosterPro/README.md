# Game Booster Pro - Phase 1

Includes: Shizuku connection (all states), supported refresh rates, lock highest refresh rate
(with automatic backup of original values + restore), WRITE_SECURE_SETTINGS grant, command log,
command whitelist with unit tests, GitHub Actions build.

## Get the APK (no PC needed)
1. Create a new GitHub repo, upload all files of this folder (keep the .github folder).
2. Open the Actions tab -> "Build APK" -> Run workflow (it also runs on every push).
3. When it turns green, open the run and download the artifact "GameBoosterPro-debug-apk".
4. Unzip, install app-debug.apk, install and start Shizuku, open the app.
