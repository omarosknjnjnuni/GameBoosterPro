package com.gamebooster.pro;

interface IUserService {
    // Reserved transaction code used by Shizuku to stop the service.
    void destroy() = 16777114;

    // Runs a shell command with Shizuku privileges.
    // Returns "<exitCode>\n<combined stdout+stderr>".
    String exec(String command) = 1;
}
