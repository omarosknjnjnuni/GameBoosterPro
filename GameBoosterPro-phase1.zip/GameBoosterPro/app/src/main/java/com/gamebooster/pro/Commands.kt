package com.gamebooster.pro

import java.util.Locale

data class ShellResult(val code: Int, val output: String) {
    val ok: Boolean get() = code == 0
}

/** Pure-Kotlin command builder + whitelist (unit-tested, no Android deps). */
object Commands {

    enum class Key(val ns: String, val key: String) {
        PEAK("system", "peak_refresh_rate"),
        MIN("system", "min_refresh_rate")
    }

    private const val PKG_PATTERN = "[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+"
    private val VALUE = Regex("^\\d{1,3}(\\.\\d{1,2})?$")
    private val PKG = Regex("^$PKG_PATTERN$")

    private val ALLOWED = listOf(
        Regex("^settings (get|delete) system (peak|min)_refresh_rate$"),
        Regex("^settings put system (peak|min)_refresh_rate \\d{1,3}(\\.\\d{1,2})?$"),
        Regex("^pm grant $PKG_PATTERN android\\.permission\\.WRITE_SECURE_SETTINGS$")
    )

    fun isValidValue(v: String) = VALUE.matches(v)

    fun get(k: Key) = "settings get ${k.ns} ${k.key}"

    fun delete(k: Key) = "settings delete ${k.ns} ${k.key}"

    fun put(k: Key, value: String): String {
        require(isValidValue(value)) { "Invalid value: $value" }
        return "settings put ${k.ns} ${k.key} $value"
    }

    fun grantWriteSecure(pkg: String): String {
        require(PKG.matches(pkg)) { "Invalid package: $pkg" }
        return "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS"
    }

    fun isAllowed(cmd: String) = ALLOWED.any { it.matches(cmd) }

    /** 120f -> "120.0" (always dot, never a locale comma). */
    fun formatRate(hz: Float): String = String.format(Locale.US, "%.1f", hz)

    /** 120f -> "120", 59.9f -> "59.9" (for display). */
    fun label(hz: Float): String =
        if (hz % 1f == 0f) hz.toInt().toString() else String.format(Locale.US, "%.1f", hz)

    /** Parses the "<code>\n<output>" string returned by UserService.exec. */
    fun parse(raw: String): ShellResult {
        val i = raw.indexOf('\n')
        if (i < 0) return ShellResult(-1, raw.trim())
        val code = raw.substring(0, i).trim().toIntOrNull() ?: -1
        return ShellResult(code, raw.substring(i + 1).trim())
    }
}
